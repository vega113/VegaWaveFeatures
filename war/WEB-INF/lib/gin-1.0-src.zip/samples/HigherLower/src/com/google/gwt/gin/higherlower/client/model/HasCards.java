package com.google.gwt.gin.higherlower.client.model;

public interface HasCards {
  void shuffle();
}
