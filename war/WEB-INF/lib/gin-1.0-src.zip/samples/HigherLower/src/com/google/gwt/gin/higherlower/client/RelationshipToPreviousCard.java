package com.google.gwt.gin.higherlower.client;

/**
 * A card's relationship to the previous card.
 */
public enum RelationshipToPreviousCard {
  HIGHER, LOWER, EQUAL
}
