/*
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.google.gwt.inject.client.generics;

import com.google.gwt.inject.client.GinModules;
import com.google.gwt.inject.client.Ginjector;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@GinModules(GenericsGinModule.class)
public interface GenericsGinjector extends Ginjector {
  List<String> getListOfString();
  List<Integer> getListOfInteger();
  LinkedList<Integer> getLinkedListOfInteger();

  Parameterized<String> getParameterized();
  Parameterized.InnerParameterized<Integer> getInnerParameterized();
  Parameterized.ComplicatedParameterized<String, Parameterized.StringComparator,
      Map<String, Parameterized.StringComparator>> getComplicatedParameterized();
  Map<String, Parameterized.StringComparator> getStringComparatorMap();

  List<? super String> getSuperStringList();
}
