package com.google.gwt.gin.higherlower.client.model;

/**
 * Playing card suit.
 */
public enum Suit {
  CLUBS, DIAMONDS, HEARTS, SPADES
}
